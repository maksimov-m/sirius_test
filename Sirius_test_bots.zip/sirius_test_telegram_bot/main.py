from aiogram import Bot, Dispatcher, executor, types
import requests
import time

TOKEN_API = "6460150280:AAFbRqfnRRY5Oy2CUrsmTH6wnhZRmGxr9wc"
API_URL = "https://api-inference.huggingface.co/models/MaximMS/myDialogModel"
headers = {"Authorization": "Bearer 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"}

bot = Bot(TOKEN_API)
dp = Dispatcher(bot)

message_history = ""
model_answer = ""
async def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()



@dp.message_handler()
async def echo(message: types.Message):
    global message_history
    if message.text == "/start":
        await message.answer(text="Можете начинать общение!)")
    else:
        message_history = message_history + f"@@ПЕРВЫЙ@@ {message.text} @@ВТОРОЙ@@"
        output = await query({
            "inputs": f"{message_history}",
            "parameters": {
                "top_k": 6,
                "top_p": 0.95,
                "num_beams": 3,
                "num_return_sequences": 1,
                "do_sample": True,
                "no_repeat_ngram_size": 2,
                "temperature": 1.2,
                "repetition_penalty": 1.2,
                "length_penalty": 1.0,
                "eos_token_id": 50257,
                "max_new_tokens": 25
            }
        })
        try:
            if output[0].get('generated_text') == None:
                while output.get('generated_text') == None:
                    time.sleep(3)
                    output = await query({
                        "inputs": f"@@ПЕРВЫЙ@@ {message.text} @@ВТОРОЙ@@",
                        "parameters": {
                            "top_k": 6,
                            "top_p": 0.95,
                            "num_beams": 3,
                            "num_return_sequences": 1,
                            "do_sample": True,
                            "no_repeat_ngram_size": 2,
                            "temperature": 1.2,
                            "repetition_penalty": 1.2,
                            "length_penalty": 1.0,
                            "eos_token_id": 50257,
                            "max_new_tokens": 25
                        }
                    })

            answer = output[0]['generated_text']
            while "@@ВТОРОЙ@@" in answer:
                n = answer.index("@@ВТОРОЙ@@")
                answer = answer[n + 10:]

            if '\\n' in answer:
                index_del = answer.index("\\n")
                answer = answer[:index_del]

            if "@@ПЕРВЫЙ@@" in answer:
                n = answer.index("@@ПЕРВЫЙ@@")
                answer = answer[:n]

            if "<SECOND_SPEAKER>" in answer:
                n = answer.index("<SECOND_SPEAKER>")
                answer = answer[:n]

            if "<FIRST_SPEAKER>" in answer:
                n = answer.index("<FIRST_SPEAKER>")
                answer = answer[:n]

            message_history = message_history + answer
            print(message_history)
            print("-----")
            if answer[-1] not in ['.', '?', '!']:
                n = -1
                while answer[n] not in ['.', '!', '?']:
                    n -= 1
                answer = answer[:len(answer) + n + 1]

            await message.answer(text=answer)
        except:
            print(output)
            await message.answer(text="Повтори попытку \nСо мной что-то не так\n:(")


if __name__ == '__main__':
    executor.start_polling(dp)
